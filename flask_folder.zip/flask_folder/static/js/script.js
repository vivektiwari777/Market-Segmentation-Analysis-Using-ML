"""
Created on Tue Nov 21 09:36:16 2023

@author: Admin
"""

var predictButton = document.getElementById('predict');
    predictButton.addEventListener('click', function() {
        console.log('hello');
    })